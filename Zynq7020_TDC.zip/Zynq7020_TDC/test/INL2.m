
%获得延时单元概率密度分布单元，的基础上绘制INL，INL:-12 to 6 LSB 比较大

clc;close all;clear;warning off;%清除变量
% 打开文件
fid = fopen('LSB_more.txt', 'r');

% 初始化一个空的数组来存储最后两位的十进制数值
lastTwoDecimal = [];

% 逐行读取文件内容
while ~feof(fid)
    % 读取一行数据
    line = fgetl(fid);
    
    % 提取最后两位
    if ~isempty(line)
        lastTwoHex = line(end-1:end);
        
        % 将最后两位十六进制转换为十进制
        lastTwoDecimal = [lastTwoDecimal, hex2dec(lastTwoHex)];
    end
end
lastTwoDecimal(lastTwoDecimal > 190) = [];
% 关闭文件
fclose(fid);

% 使用 histfit 绘制统计图
histfit(lastTwoDecimal, 190);  % 10 表示直方图的箱数

% 获取直方图的计数数据和对应的码值
h = histcounts(lastTwoDecimal, 190); % 获取直方图数据

mean_h = mean(h);
dnl = h / mean_h - 1;
inl = cumsum(dnl);

%figure;
%plot(1:190, inl);
%xlabel('Bin Index');
%ylabel('INL (LSB)');
%title('Integral Nonlinearity');
%grid on;



% 绘制DNL图
figure;
bar(1:190, inl); % 使用蓝色条形图表示
xlabel('Delay chain/Index');
ylabel('INL/LSB');
title('Integral Nonlinearity');
grid on;