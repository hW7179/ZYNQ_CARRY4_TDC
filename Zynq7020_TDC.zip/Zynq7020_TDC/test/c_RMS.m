% 读取数据文件
data = load('FWHM_1000ns.txt');

% 计算RMS值
%rms_value = sqrt(mean(data.^2));
rms_value =  sqrt(mean((data - 999974).^2));
% 显示结果
disp(['数据的RMS值为: ', num2str(rms_value)]);

% 读取数据文件
data = load('FWHM_600ns.txt');

% 计算RMS值
%rms_value = sqrt(mean(data.^2));
rms_value =  sqrt(mean((data - 599985).^2));
% 显示结果
disp(['数据的RMS值为: ', num2str(rms_value)]);