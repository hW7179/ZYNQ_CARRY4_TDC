%获得延时单元概率密度分布单元，

clc;close all;clear;warning off;%清除变量
% 打开文件
fid = fopen('LSB_more.txt', 'r');

% 初始化一个空的数组来存储最后两位的十进制数值
lastTwoDecimal = [];

% 逐行读取文件内容
while ~feof(fid)
    % 读取一行数据
    line = fgetl(fid);
    
    % 提取最后两位
    if ~isempty(line)
        lastTwoHex = line(end-1:end);
        
        % 将最后两位十六进制转换为十进制
        lastTwoDecimal = [lastTwoDecimal, hex2dec(lastTwoHex)];
    end
end
lastTwoDecimal(lastTwoDecimal > 188) = [];
% 关闭文件
fclose(fid);

% 使用 histfit 绘制统计图
histfit(lastTwoDecimal, 190);  % 10 表示直方图的箱数

% 设置图形标题和标签
title('Chain Density');
xlabel('Delay chain/Index');
ylabel('Count/Num');