% 读取数据（假设数据保存在data.txt中）
data = load('FWHM_600ns1.txt');

% 绘制计数直方图
figure;
h = histogram(data, 'BinWidth', 50, 'Normalization', 'count'); % 显示实际计数
hold on;

% 高斯拟合（基于原始数据）
pd = fitdist(data, 'Normal');
mu = pd.mu;
sigma = pd.sigma;

% 生成拟合曲线（转换为计数比例）
numData = numel(data);         % 数据总数
binWidth = h.BinWidth;         % 获取直方图分箱宽度
x = linspace(min(data), max(data), 1000);
y = numData * binWidth * pdf(pd, x); % 将概率密度转换为计数比例
plot(x, y, 'LineWidth', 2, 'Color', 'r');

% 计算FWHM
fwhm = 2.3548 * sigma; % FWHM = 2.3548σ

% 添加标签和标题
xlabel('Time(ps)');
ylabel('Count');
title('Count Histogram with Gaussian Fit');
%legend('Histogram (Counts)', 'Gauss Fit');
legend('Histogram (Counts)', ['Gaussian Fit (\mu=' num2str(mu, '%.0f') ', \sigma=' num2str(sigma, '%.0f') ')']);

% 显示FWHM
text(mean(x), max(h.Values)*0.7, ['FWHM = ' num2str(fwhm, '%.2f')], 'FontSize', 10, 'Color', 'k');
grid on;

% 输出结果
disp(['高斯拟合的均值为: ', num2str(mu)]);
disp(['高斯拟合的标准差为: ', num2str(sigma)]);
disp(['半高宽(FWHM)为: ', num2str(fwhm)]);