#include <stdio.h>
#include <stdlib.h>
//#include "platform.h"
#include "xil_printf.h"
#include "xscugic.h" //中断头文件
#include "xparameters.h"//设备ID
#include "myip_tdc_bram.h"
#include "xbram.h"
#include "ff.h" //包含文件系统相关函数和变量的声明
#include "xdevcfg.h" //包含操作 SD 卡过程中的状态变量
#define FILE_NAME "TDCDATA.txt" //定义文件名
static FATFS fatfs; //文件系统

#define START_ADDR 0 //RAM 起始地址 范围:0~1023
#define BRAM_DATA_BYTE 4 //BRAM 数据字节个数


/*step1 重定义*/
#define GIC_DEV_ID XPAR_PS7_SCUGIC_0_DEVICE_ID
#define GIC_BASEADDR XPAR_PS7_SCUGIC_0_DIST_BASEADDR
#define F2P_DEV_INTR0 61 //1s中断源对应的ID
#define INTR_PORI 32 //F2P中断优先级
#define TRIG_TYPE 3  //F2P中断触发类型 2'b01 高电平触发，2'b11 = 3为上升沿触发
const char startstr[30] = "TDC_timestamp\n";
const char newline[] = "\n";
int read_flag;
int ch_data_len; //写入 BRAM 的字符个数


/*step2 变量定义*/
XScuGic ScuGic;
XScuGic_Config *ScuGicCfgPtr;


/*step3 函数声明*/
int Init_Gic(void);
void F2P0_Handler(void *data);//1s中断处理函数
int sd_mount(void);
int platform_init_fs(void);


int Init_Gic(void)
{
    int status = 0;
    /*step1、初始化异常处理*/
    Xil_ExceptionInit();
    /*step2、初始化中断控制器*/
    ScuGicCfgPtr = XScuGic_LookupConfig(GIC_DEV_ID);
    status = XScuGic_CfgInitialize(&ScuGic,ScuGicCfgPtr,ScuGicCfgPtr->CpuBaseAddress);
    if(status != XST_SUCCESS)
    {
        printf("Initial Gic Failed!");
        return status;
    }
    /*step3、注册异常处理回调函数*/
    Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler)XScuGic_InterruptHandler,&ScuGic);
    /*step4.异常处理使能*/
    Xil_ExceptionEnable();

    /******配置区域*******/
    /*step5、在gic中使能（被中断的设备ID）*/
    XScuGic_Enable(&ScuGic,F2P_DEV_INTR0);

    /*step6、在gic中连接被中断的设备ID,并注册回调函数*/

    status = XScuGic_Connect(&ScuGic,F2P_DEV_INTR0,(Xil_ExceptionHandler)F2P0_Handler,&ScuGic);
    if(status != XST_SUCCESS)
    {
        printf("Connect Gic Failed!");
        return status;
    }
    /*step7、设置F2P中断源优先级和触发类型*///设置触发类型是因为F2P有两种触发方式让你选
    XScuGic_SetPriTrigTypeByDistAddr(GIC_BASEADDR,F2P_DEV_INTR0,INTR_PORI,TRIG_TYPE);
    /*step8、在双核架构下需要，将硬件ID与对应的CPU相连接*/
//    XScuGic_InterruptMaptoCpu(&ScuGic,0,F2P_DEV_INTR0);

    return XST_SUCCESS;
}


//初始化文件系统
int platform_init_fs(void)
{
	FRESULT status;
	TCHAR *Path = "0:/";
	BYTE work[FF_MAX_SS];

	//注册一个工作区(挂载分区文件系统)
	//在使用任何其它文件函数之前，必须使用 f_mount 函数为每个使用卷注册一个工作区
	status = f_mount(&fatfs, Path, 1); //挂载 SD 卡
	if (status != FR_OK) {
		xil_printf("Volume is not FAT formated; formating FAT\r\n");
		//格式化 SD 卡
		status = f_mkfs(Path, FM_FAT32, 0, work, sizeof work);
		if (status != FR_OK) {
			xil_printf("Unable to format FATfs\r\n");
			return -1;
		}
		//格式化之后，重新挂载 SD 卡
		status = f_mount(&fatfs, Path, 1);
		if (status != FR_OK) {
			xil_printf("Unable to mount FATfs\r\n");
			return -1;
		}
	}
	return 0;
}

//挂载 SD(TF)卡
int sd_mount(void)
{
	int status;
	//初始化文件系统（挂载 SD 卡，如果挂载不成功，则格式化 SD 卡）
	status = platform_init_fs();
	if(status){
		xil_printf("ERROR: f_mount returned %d!\n",status);
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}
//SD 卡写数据
int sd_write_data(char *file_name,u32 src_addr,u32 byte_len)
{
	FIL fil; //文件对象
	UINT bw; //f_write 函数返回已写入的字节数

	//打开一个文件,如果不存在，则创建一个文件
	f_open(&fil,file_name,FA_CREATE_ALWAYS | FA_WRITE);
	//移动打开的文件对象的文件读/写指针 0:指向文件开头
	f_lseek(&fil, 0);
	//向文件中写入数据
	f_write(&fil,(void*) src_addr,byte_len,&bw);
	//关闭文件
	f_close(&fil);
	return 0;
}

void F2P0_Handler(void *data)
{
    printf("Bram read start!\n\r");
    char data_string[8]={0};

    int read_data=0,i=0;
    int data_len;
    int newline_len;
	int startstr_len;

	FIL fil; //文件对象
	UINT bw; //f_write 函数返回已写入的字节数
	newline_len = strlen(newline);

	//打开一个文件,如果不存在，则创建一个文件
	f_open(&fil,FILE_NAME,FA_CREATE_ALWAYS | FA_WRITE);
	//移动打开的文件对象的文件读/写指针 0:指向文件开头
	f_lseek(&fil, 0);
	//写入sd首行提示信息：TDC_timestamp
	startstr_len = strlen(startstr);
	f_write(&fil,(void*) startstr,startstr_len,&bw);
	//循环从 BRAM 中读出数据
	for(i = BRAM_DATA_BYTE*START_ADDR ; i < BRAM_DATA_BYTE*(START_ADDR + ch_data_len) ;i += BRAM_DATA_BYTE)
	{
		read_data = XBram_ReadReg(XPAR_BRAM_0_BASEADDR,i) ;//从BRAM读取数据
	    itoa(read_data,data_string,16);//数字转字符串
	    //数据写入sd
		data_len = strlen(data_string);
		f_write(&fil,(void*) data_string,data_len,&bw);
		f_write(&fil,(void*) newline,newline_len,&bw);

		printf("BRAM address is:%d,   BRAM read_data is:%s,   Send data is:%x %s \n",i,data_string,i,data_string) ;
	}

	f_close(&fil);
	printf("SD write end\n") ;
}
int main()
{
	int status;
    ch_data_len = 1024;
	printf("test start!\n\r");

	//挂载 SD 卡
	status = sd_mount();
	if(status != XST_SUCCESS){
		 xil_printf("Failed to open SD card!\n");
		 return 0;
	}
	else xil_printf("Success to open SD card!\n");

	//初始化中断
    Init_Gic();

    while(1)
    {

    }
    return 0;
}
